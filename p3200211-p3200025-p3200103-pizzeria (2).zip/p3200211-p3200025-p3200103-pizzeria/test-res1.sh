gcc -Wall -pthread p3200211-p3200025-p3200103.c
./a.out 100 1000

